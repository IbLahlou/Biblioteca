=== ChatBot.tn Plugin ===
Contributors: Spimob
Tags: ChatBot.tn, Bots, Chatbots, WordPress.com, Wordpress Chatbot, chatbot.tn plugins, spimob plugins, spimob wordpress plugin, chatbot.tn wordpress plugin, spimob wordpress chatbot
Stable tag: 1.2.1
Requires at least: 4.7
Tested up to: 5.0.2

The ideal plugin to build a no-code chatbot and Live chat for your web site and your Facebook Messenger

This plugin is to embed ChatBot.tn Website Chatbot into wordpress site.

== Description ==

This plugin is to embed ChatBot.tn Website Chatbot into wordpress site.

ChatBot.tn is the easiest way to design, build and publish your chatbot for your website and your Facebook Messenger in minutes


= Get Started =
You can get Website Chatbot quick, and easy. [Get Website Chatbot from our site](https://chatbot.tn) in minutes.

== Installation ==

= Automated Installation =
Install this wordpress plugin, get your API Key from ChatBot.tn and activate your ChatBot.tn Bot on your Website

= Manual Alternatives =
Get embed Code from your Bot Dashboard on ChatBot.tn, and put that code before &lt;/body&gt; on any page where you want to enable bot 

== Changelog ==

= 1.0.1 =
* Release date: October 13, 2021
